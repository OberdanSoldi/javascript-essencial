const arr = [1, 2, [3, 4]];

arr.flat();
// [1, 2, 3, 4]