const arr = [1, 2, 3, 4];

const firstGreaterThanTwo = arr.findIndex(value => value > 2);

console.log(firstGreaterThanTwo);
// 2