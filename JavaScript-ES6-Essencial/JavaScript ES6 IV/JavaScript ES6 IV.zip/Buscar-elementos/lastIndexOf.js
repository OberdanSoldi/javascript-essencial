const arr = [1, 3, 3, 4, 3];
const lirstIndexOfItem = arr.lastIndexOf(3)

console.log(lastIndexofItem);
// 4