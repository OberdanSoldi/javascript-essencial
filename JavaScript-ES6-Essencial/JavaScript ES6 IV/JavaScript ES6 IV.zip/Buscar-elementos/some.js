const arr = [1, 3, 3, 4, 3];
const hasSomeEverNumber = arr.some(value => value % 2 === 0);
// True