const allEvenNumbers = arr.every(value => value % 2 === 0);
// False