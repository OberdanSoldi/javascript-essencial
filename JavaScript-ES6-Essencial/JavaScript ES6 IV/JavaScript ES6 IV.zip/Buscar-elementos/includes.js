const arr = [1, 3, 3, 4, 3];

const hasItemOne = arr.includes(1);
// True

const hasItemTwo = arr.includes(2);
// False