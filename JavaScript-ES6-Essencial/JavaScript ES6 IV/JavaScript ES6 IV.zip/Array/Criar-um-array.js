const arr = [1, 2, 3];
const arr2 = new Array(1, 2, 3);