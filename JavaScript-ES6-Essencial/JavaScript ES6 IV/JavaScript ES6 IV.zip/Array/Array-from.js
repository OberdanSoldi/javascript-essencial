const divs = document.querySelectorAll("div");
const arr = Array.from("divs");