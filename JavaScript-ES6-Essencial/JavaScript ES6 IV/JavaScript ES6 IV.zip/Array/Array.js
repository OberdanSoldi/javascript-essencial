const arr = Array(3);
//empty

const arr2 = Array(3, 2);
//2, 3