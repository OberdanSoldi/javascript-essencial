const arr = ['banana', 'melancia', 'abacate'];
const arrLenght = arr.unshift('acerola');

console.log(arrLenght);
// 4

console.log(arr);
// ['banana', 'melancia', 'abacate', 'acerola'];