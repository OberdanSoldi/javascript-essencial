const arr = ['banana', 'melancia', 'abacate'];
const arrLenght = arr.shift();

console.log(arrLenght);
// 'banana'

console.log(arr);
// ['melancia', 'abacate'];