const arr = ['banana', 'melancia', 'abacate'];
const removedItem = arr.pop();

console.log(removedItem);
// 'abacate'

console.log(arr);
// ['banana', 'melancia'];