'use strict';

//Exemplo da implementação simples de um objetos.

function Animal() {
    this.qtdePatas = 4;
}

const cachorro = new Animal();
console.log(cachorro.qtdePatas);


