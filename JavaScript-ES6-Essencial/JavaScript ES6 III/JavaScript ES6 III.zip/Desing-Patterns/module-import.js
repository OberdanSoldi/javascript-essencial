const {getName, setName} = require('/Desing-Patterns/Module');

console.log(getName());
console.log(setName('Guilherme'));
console.log(getName());