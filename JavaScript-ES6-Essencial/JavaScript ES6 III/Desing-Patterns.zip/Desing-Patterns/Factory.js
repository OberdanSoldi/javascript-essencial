function user(customProperties) {
    return {
        name: 'Giovanna',
        lastname: 'Ramos',
        ...customProperties
    }
}

const p = pessoas({name: 'Custom-Name', age: 27});
console.log(p);